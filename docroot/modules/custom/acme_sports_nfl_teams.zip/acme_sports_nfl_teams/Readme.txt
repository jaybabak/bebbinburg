Readme:
-- Enable module and place the Acme Sports NFL Teams Block on any page,
-- Configuration menu is located at: /admin/config/acme-sports/settings

Thank you!