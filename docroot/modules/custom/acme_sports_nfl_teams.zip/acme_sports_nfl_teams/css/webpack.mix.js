let mix = require('laravel-mix');

mix.sass('src/acme_sports_nfl_teams.scss', 'dist/acme_sports_nfl_teams.min.css');
